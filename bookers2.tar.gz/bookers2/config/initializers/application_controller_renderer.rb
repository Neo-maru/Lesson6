# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '2dfa66ce9c5bafac6682bee74e589384b63255f90d70efab890fbd13ca0cfdf8bb7e5fdecaff81e69c4ce5a8dcd7218fc75cb41ebd9f454cdc14ddbe96f36333'
